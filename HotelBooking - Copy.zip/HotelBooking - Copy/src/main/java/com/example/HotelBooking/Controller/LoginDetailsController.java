package com.example.HotelBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.HotelBooking.Entity.LoginDetails;
import com.example.HotelBooking.Service.LoginDetailsService;

@RestController

public class LoginDetailsController {

	@Autowired
	private LoginDetailsService logindetailsservice;
	
	@PostMapping("/addLogin")
	public LoginDetails postDetails(@RequestBody LoginDetails logindetails){
		
		return logindetailsservice.savedetails(logindetails);
	}
	
}
