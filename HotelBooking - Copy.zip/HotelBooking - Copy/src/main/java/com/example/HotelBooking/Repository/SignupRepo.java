package com.example.HotelBooking.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.HotelBooking.Entity.SignupDetails;

@Repository
public interface SignupRepo extends JpaRepository<SignupDetails, Integer>{

}
