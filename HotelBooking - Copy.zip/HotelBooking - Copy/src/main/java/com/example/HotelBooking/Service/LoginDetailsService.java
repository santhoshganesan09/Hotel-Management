package com.example.HotelBooking.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HotelBooking.Entity.LoginDetails;
import com.example.HotelBooking.Repository.LoginRepo;

@Service

public class LoginDetailsService {
	
	@Autowired
	private LoginRepo loginrepo;
	
	public LoginDetails savedetails(LoginDetails logindetails) {
		
		return loginrepo.save(logindetails);
	}
	
}

