package com.example.HotelBooking.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="BookingDetails")
public class BookinDetails { 
	
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id ;
	
	@Column(name= "First_Name")
	private String fname;
	
	@Column(name = "Last_name")
	private String lname;
	
	@Column(name="Chick-in Date")
	private int chick_indate;
	
	@Column(name="Chick-in Time")
	private int chick_intime;
	
	@Column(name="Chick-out Date ")
	private int chick_outdate;
	
	@Column(name="Chick-our Time")
	private int chick_outtime;
	
	@Column(name="Room Preferance")
	private String roomprefeance;
	
	@Column(name="Adults")
	private int adults;
	
	@Column(name="Childern")
	private int childern;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public int getChick_indate() {
		return chick_indate;
	}

	public void setChick_indate(int chick_indate) {
		this.chick_indate = chick_indate;
	}

	public int getChick_intime() {
		return chick_intime;
	}

	public void setChick_intime(int chick_intime) {
		this.chick_intime = chick_intime;
	}

	public int getChick_outdate() {
		return chick_outdate;
	}

	public void setChick_outdate(int chick_outdate) {
		this.chick_outdate = chick_outdate;
	}

	public int getChick_outtime() {
		return chick_outtime;
	}

	public void setChick_outtime(int chick_outtime) {
		this.chick_outtime = chick_outtime;
	}

	public String getRoomprefeance() {
		return roomprefeance;
	}

	public void setRoomprefeance(String roomprefeance) {
		this.roomprefeance = roomprefeance;
	}

	public int getAdults() {
		return adults;
	}

	public void setAdults(int adults) {
		this.adults = adults;
	}

	public int getChildern() {
		return childern;
	}

	public void setChildern(int childern) {
		this.childern = childern;
	}

	public BookinDetails() {
		super();
	}

	

	
	
	
	
	
}
