package com.example.HotelBooking.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.HotelBooking.Entity.SignupDetails;
import com.example.HotelBooking.Service.SignupDetailsService;

@RestController
public class SignupDetailsController {
	
	@Autowired
	private SignupDetailsService signupdetailsservice;
	
	@PostMapping("/addSignup")
	public SignupDetails postDetails(@RequestBody SignupDetails signupdetails) {
		return signupdetailsservice.savedetails(signupdetails);
	}
}
