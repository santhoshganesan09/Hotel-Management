package com.example.HotelBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.HotelBooking.Entity.BookinDetails;
import com.example.HotelBooking.Service.BookingdetailsService;

@RestController

public class BookingController {
	
	@Autowired
	private BookingdetailsService bookingdetailsService;
	
	@PostMapping("/addBookingdetails")
	 public BookinDetails postDetails(@RequestBody BookinDetails bookindetails ){
		
		return bookingdetailsService.saveDetails(bookindetails);
	}
	
}
