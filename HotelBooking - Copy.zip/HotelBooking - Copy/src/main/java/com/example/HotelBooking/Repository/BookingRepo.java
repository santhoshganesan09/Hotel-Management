package com.example.HotelBooking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.HotelBooking.Entity.BookinDetails;

@Repository
public interface BookingRepo extends JpaRepository<BookinDetails, Integer> {
 
}
