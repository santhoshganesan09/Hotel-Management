package com.example.HotelBooking.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="PersonalDetails")
public class PersonalDetails {

	@Id
	@Column(name ="ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name= "First_Name")
	private String fname;
	
	@Column(name = "Last_name")
	private String lname;
	
	@Column(name="DOB")
	private Integer DOB;
	
	@Column(name="PhoneNumber")
	private int ph;
	
	@Column(name="Address1")
	private String address1;
	
	
	@Column(name="City")
	private String city;
	
	@Column(name="Pincode")
	private int pincode;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Integer getDOB() {
		return DOB;
	}

	public void setDOB(Integer dOB) {
		DOB = dOB;
	}

	public int getPh() {
		return ph;
	}

	public void setPh(int ph) {
		this.ph = ph;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public PersonalDetails() {
		super();
	}

	
	
	
	
	
	
	
	
	
	
}
