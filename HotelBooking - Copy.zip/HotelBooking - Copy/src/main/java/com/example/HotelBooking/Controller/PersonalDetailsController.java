package com.example.HotelBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.HotelBooking.Entity.PersonalDetails;
import com.example.HotelBooking.Service.PersonaldetailsServices;

@RestController
public class PersonalDetailsController {

	@Autowired
	private PersonaldetailsServices personaldetailservice;
	
	
	@PostMapping("/addPersonalDetails")
	public PersonalDetails postDetails(@RequestBody PersonalDetails personaldetails) {
		 
		return personaldetailservice.savedetails(personaldetails);
	}
}
