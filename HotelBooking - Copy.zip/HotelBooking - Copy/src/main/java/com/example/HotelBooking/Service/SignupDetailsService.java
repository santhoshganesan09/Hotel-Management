package com.example.HotelBooking.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HotelBooking.Entity.SignupDetails;
import com.example.HotelBooking.Repository.SignupRepo;

@Service
public class SignupDetailsService {

	@Autowired
	private SignupRepo signuprepo;
	
	public SignupDetails savedetails(SignupDetails signupdetails) {
		
		return signuprepo.save(signupdetails);
	}
	
}
