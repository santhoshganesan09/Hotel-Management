package com.example.HotelBooking.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HotelBooking.Entity.PersonalDetails;
import com.example.HotelBooking.Repository.PersonalRepo;

@Service
public class PersonaldetailsServices {

	@Autowired
	private PersonalRepo personalrepo;
	
	public PersonalDetails savedetails(PersonalDetails personaldetails) {
		
		return personalrepo.save(personaldetails);
	}
	
	
}
