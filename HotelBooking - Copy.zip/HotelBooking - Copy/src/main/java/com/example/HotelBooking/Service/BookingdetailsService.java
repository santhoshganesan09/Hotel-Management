package com.example.HotelBooking.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HotelBooking.Entity.BookinDetails;
import com.example.HotelBooking.Repository.BookingRepo;

@Service
public class BookingdetailsService {
	
	@Autowired 
	private BookingRepo bookingRepo;

	public  BookinDetails saveDetails(BookinDetails bookindetails) {
		
		return bookingRepo.save(bookindetails);
	}
		
		
	 	 
}
